---
layout: default
lang: vn
lang_title: Bộ quy tắc viết SQL
contributors:
    - user: DancingPhoenix88
      type: translator
---

* MỤC LỤC
{:toc}

{% include sqlstyle.guide.vn.md %}
