---
layout: default
lang: tr
lang_title: SQL Stil Rehberi
contributors:
    - user: mrfade
      type: translator
---

* TOC
{:toc}

{% include sqlstyle.guide.tr.md %}