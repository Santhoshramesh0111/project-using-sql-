---
layout: default
lang: pl
lang_title: Podręcznik stylu SQL
contributors:
    - user: andre-wojtowicz
      type: translator
---

* TOC
{:toc}

{% include sqlstyle.guide.pl.md %}
