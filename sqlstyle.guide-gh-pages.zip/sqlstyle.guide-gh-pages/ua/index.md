---
layout: default
lang: ua
lang_title: Посібник зі стиль-коду SQL
contributors:
    - user: yar-lukomsky
      type: translator
---

* TOC
{:toc}

{% include sqlstyle.guide.ua.md %}
