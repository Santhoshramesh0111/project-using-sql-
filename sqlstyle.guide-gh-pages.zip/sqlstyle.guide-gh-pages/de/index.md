---
layout: default
lang: de
lang_title: SQL-Styleguide
contributors:
    - user: AStasyK
      type: translator
---

* TOC
{:toc}

{% include sqlstyle.guide.de.md %}
