---
layout: default
lang: pt-BR
lang_title: Guia de Estilo SQL
contributors:
    - user: pmarcus93
      type: translator
---

* TOC
{:toc}

{% include sqlstyle.guide.pt-BR.md %}
