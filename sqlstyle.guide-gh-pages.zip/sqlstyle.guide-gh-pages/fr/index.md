---
layout: default
lang: fr
lang_title: Guide de style SQL
contributors:
    - user: IdrissaD
      type: translator
---

* TOC
{:toc}

{% include sqlstyle.guide.fr.md %}
