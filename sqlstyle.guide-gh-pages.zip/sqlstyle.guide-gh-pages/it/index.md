---
layout: default
lang: it
lang_title: Guida allo stile SQL
contributors:
    - user: robertopauletto
      type: translator
---

* TOC
{:toc}

{% include sqlstyle.guide.it.md %}
