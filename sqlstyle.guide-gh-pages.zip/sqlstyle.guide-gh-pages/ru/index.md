---
layout: default
lang: ru
lang_title: Руководство по стилю SQL
contributors:
    - user: denpatin
      type: translator
---

* TOC
{:toc}

{% include sqlstyle.guide.ru.md %}
